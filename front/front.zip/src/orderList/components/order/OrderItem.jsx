import React from "react";
import '../order/orderitem.css'

const OrderItem = ({ order, onSelect }) => {


  const handleClick=()=>{
    onSelect(order.robot_id);
  }

  return (
    <div className="orderitem-card" onClick={handleClick}>
      <span className="orderitem-info">주문 번호: {order.order_id}</span>
      <span className="orderitem-info">주문 내역: {order.items}</span>
      <span className="orderitem-info">주문 주소: {order.dest}</span>
      {/* <span className="orderitem-info">상태:  {order.status}</span> */}
      <span className="orderitem-info">총 금액:  {order.total_amount}</span>
    </div>
  );
};

export default OrderItem;
