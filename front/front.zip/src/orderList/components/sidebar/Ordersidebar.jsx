import React from 'react'

const Ordersidebar = ({onClick}) => {

    

  return (
    <div>Ordersidebar</div>
  )
}

export default Ordersidebar