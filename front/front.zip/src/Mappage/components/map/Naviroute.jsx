import React from 'react'

const Naviroute = () => {
  return (
    <div>Naviroute</div>
  )
}

export default Naviroute