import { useEffect, useState } from "react";

const RobotMovement = ({ setRobotPosition, clickRobot }) => {
  const [routeIndex, setRouteIndex] = useState(0);

  // ✅ 미리 지정한 로봇 이동 경로
  const predefinedRoute = [
    { y: 126.912773, x: 35.151954 }, // 시작점
    { y: 126.913124, x: 35.151670 },
    { y: 126.913654, x: 35.151306 }, // 중간 지점
    { y: 126.913948, x: 35.150957 },
    { y: 126.913545, x: 35.150641 }, // 매장 근처 (20m 반경)
  ];

  console.log(clickRobot);

  // ✅ 매장 좌표 (예제: 신락원)
  // const storeLocation = { x: 126.920000, y: 35.154000 };

  // ✅ 5초마다 로봇 이동
  useEffect(() => {
    const interval = setInterval(() => {
      if (routeIndex < predefinedRoute.length) {
        const nextPosition = predefinedRoute[routeIndex];
        setRobotPosition(nextPosition); // ✅ 부모 컴포넌트에서 로봇 위치 업데이트
        setRouteIndex(routeIndex + 1);

        console.log(nextPosition.y);
        // ✅ 매장 반경 20m 이내인지 확인
        const distance = getDistance(nextPosition.y, nextPosition.x, clickRobot.store_y, clickRobot.store_x);
        if (distance <= 20) {
            alert("🚀 로봇이 매장 반경 20m 내로 진입! 상태 변경: '픽업 대기'");
        }
        } else {
        clearInterval(interval);
        }
    }, 5000);

    return () => clearInterval(interval);
    }, [routeIndex]);

  // 📌 두 좌표 간 거리 계산 (Haversine 공식)
    const getDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371000;
    const toRad = (degree) => (degree * Math.PI) / 180;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
    };

  return null; // UI 요소 없이 기능만 수행
};

export default RobotMovement;
