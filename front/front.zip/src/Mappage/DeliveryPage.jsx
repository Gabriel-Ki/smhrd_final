import React, { useEffect, useState } from 'react'
import KakaoMap from './components/map/Kakaomap';
import Sidebar from './components/sidebar/Sidebar';
import '../Mappage/Deliverypage.css'


const DeliveryPage = () => {

  const [selectRobot,setSelectRobot]=useState(null); // 선택된 주문 정보
  // const [order,setOrders]=useState([]); // api에서 받은 주문 데이터
  // const [robots,setRobots]=useState([]); // api에서 받은 로봇 데이터

  // useEffect(()=>{
  //   const fetchData=()=>{
  //     try{
  //       const orderResponse = await fetch("http://api.example.com/orders");
  //       const orderData=await orderResponse.json()
  //     }
  //   }
  // })


  return (
    <div className='delivery-page'>
      <div className='delivery-header'>팀장선</div>
      <div className='delivery-container'>
        {/* 지도와 사이드바 */}
        <div className='delivery-box'>
          {/* 지도 */}
          <div className='delivery-map'>
            <KakaoMap onRobotSelect={setSelectRobot} />
          </div>
          {/* 사이드바 */}
          <div className='delivery-sidebar'>
            <Sidebar selectRobot={selectRobot}/>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DeliveryPage;